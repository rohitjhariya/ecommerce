<style>
    .img-fluid {
    max-width: 76% !important;
    height: auto !important;
}
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h4>View Seller Profile</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('admin/home') ?>">Home</a></li>
                        <li class="breadcrumb-item active">Seller</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">

                <div class="col-md-12">
                    <div class="card card-info">
                        <!-- form start -->
                        <form class="form-horizontal form-submit-event" action="<?= base_url('seller/login/update_user'); ?>" method="POST" id="add_product_form">
                            <?php if (isset($fetched_data[0]['id'])) { ?>
                                <input type="hidden" name="edit_seller" value="<?= $fetched_data[0]['user_id'] ?>">
                                <input type="hidden" name="edit_seller_data_id" value="<?= $fetched_data[0]['id'] ?>">
                                <input type="hidden" name="old_address_proof" value="<?= $fetched_data[0]['address_proof'] ?>">
                                <input type="hidden" name="old_store_logo" value="<?= $fetched_data[0]['logo'] ?>">
                                <input type="hidden" name="old_authorized_signature" value="<?= $fetched_data[0]['authorized_signature'] ?>">
                                <input type="hidden" name="old_national_identity_card" value="<?= $fetched_data[0]['national_identity_card'] ?>">
                            <?php
                            } ?>
                            <div class="card-body row">
                                <div class="col-lg-6">
                                    <h4>Seller details</h4>
                                <div class="seller-profile">
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="name" class=" col-form-label">Name <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="name" placeholder="Seller Name" name="name" value="<?= @$fetched_data[0]['username'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="mobile" class="col-form-label">Mobile <span class='text-danger text-sm'></span></label>
                                        <input type="number" class="form-control" id="mobile" placeholder="Enter Mobile" name="mobile" value="<?= @$fetched_data[0]['mobile'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="email" class=" col-form-label">Email <span class='text-danger text-sm'></span></label>
                                        <input type="email" class="form-control" id="email" placeholder="Enter Email" name="email" value="<?= @$fetched_data[0]['email'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row d-none">
                                    <div class="col-sm-12">
                                        <label for="old" class="col-form-label">Old Password</label>
                                        <input type="password" class="form-control" id="old" placeholder="Type Password here" name="old">
                                    </div>
                                </div>
                                <div class="form-group row d-none">
                                    <div class="col-sm-12">
                                        <label for="new" class="col-form-label">New Password</label>
                                        <input type="password" class="form-control" id="new" placeholder="Type Password here" name="new">
                                    </div>
                                </div>
                                <div class="form-group row d-none">
                                    <div class="col-sm-12">
                                        <label for="new_confirm" class="col-form-label">Confirm New Password</label>
                                        <input type="password" class="form-control" id="new_confirm" placeholder="Type Confirm Password here" name="new_confirm">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="address" class="col-form-label">Address <span class='text-danger text-sm'></span></label>
                                        <textarea type="text" class="form-control" id="address" placeholder="Enter Address" name="address" readonly><?= isset($fetched_data[0]['address']) ? @$fetched_data[0]['address'] : ""; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row d-none">
                                    <div class="col-sm-12">
                                        <label for="address_proof" class="col-form-label">Address Proof <span class='text-danger text-sm'>*</span> </label>
                                        <?php if (isset($fetched_data[0]['address_proof']) && !empty($fetched_data[0]['address_proof'])) { ?>
                                            <span class="text-danger">*Leave blank if there is no change</span>
                                        <?php } ?>
                                        <input type="file" class="form-control" name="address_proof" id="address_proof" accept="image/*" />
                                    </div>
                                </div>
                                <?php if (isset($fetched_data[0]['address_proof']) && !empty($fetched_data[0]['address_proof'])) { ?>
                                    <div class="form-group row">
                                        <div class="mx-auto product-image"><a href="<?= base_url($fetched_data[0]['address_proof']); ?>" data-toggle="lightbox" data-gallery="gallery_seller"><img src="<?= base_url($fetched_data[0]['address_proof']); ?>" class="img-fluid rounded"></a></div>
                                    </div>
                                <?php } ?>
                                <div class="form-group row d-none">
                                    <div class="col-sm-12">
                                        <label for="authorized_signature" class="col-form-label">Authorized Signature <span class='text-danger text-sm'></span></label>
                                        <?php if (isset($fetched_data[0]['authorized_signature']) && !empty($fetched_data[0]['authorized_signature'])) { ?>
                                            <span class="text-danger">*Leave blank if there is no change</span>
                                        <?php } ?>
                                        <input type="file" class="form-control" name="authorized_signature" id="authorized_signature" accept="image/*" />
                                    </div>
                                </div>
                                <?php if (isset($fetched_data[0]['authorized_signature']) && !empty($fetched_data[0]['authorized_signature'])) { ?>
                                    <div class="form-group row">
                                        <div class="mx-auto product-image"><a href="<?= base_url($fetched_data[0]['authorized_signature']); ?>" data-toggle="lightbox" data-gallery="gallery_seller"><img src="<?= base_url($fetched_data[0]['authorized_signature']); ?>" class="img-fluid rounded"></a></div>
                                    </div>
                                <?php } ?>
                                </div>
                                </div>
                                
                                <hr>
                                <div class="col-lg-6">
                                <h4>Store Details</h4>
                                <div class="storedetails mb-2">
                                   
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="store_name" class="col-form-label">Name <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="store_name" placeholder="Store Name" name="store_name" value="<?= @$fetched_data[0]['store_name'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="store_url" class="col-form-label">URL <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="store_url" placeholder="Store URL" name="store_url" value="<?= @$fetched_data[0]['store_url'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="store_description" class="col-form-label">Description <span class='text-danger text-sm'></span></label>
                                        <textarea type="text" class="form-control" id="store_description" placeholder="Store Description" name="store_description" readonly><?= isset($fetched_data[0]['store_description']) ? @$fetched_data[0]['store_description'] : ""; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <!-- <label for="logo" class="col-form-label">Logo <span class='text-danger text-sm'></span></label> -->
                                        <?php if (isset($fetched_data[0]['logo']) && !empty($fetched_data[0]['logo'])) { ?>
                                            <!-- <span class="text-danger">*Leave blank if there is no change</span> -->
                                        <?php } ?>
                                        <!-- <input type="file" class="form-control" name="store_logo" id="store_logo" accept="image/*" readonly/> -->
                                    </div>
                                </div>
                                <?php if (isset($fetched_data[0]['logo']) && !empty($fetched_data[0]['logo'])) { ?>
                                    <div class="form-group row">
                                        <div class="product-image"><a href="<?= base_url($fetched_data[0]['logo']); ?>" data-toggle="lightbox" data-gallery="gallery_seller"><img src="<?= base_url($fetched_data[0]['logo']); ?>" class="img-fluid rounded"></a></div>
                                    </div>
                                <?php } ?>
                                </div>
                                </div>
                                
                                <hr>
                                <div class="col-lg-6">
                                <h4>Bank Details</h4>
                                <div class="bank-detail">
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="account_number" class="col-form-label">Account Number <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="account_number" placeholder="Account Number" name="account_number" value="<?= @$fetched_data[0]['account_number'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="account_name" class="col-form-label">Account Name <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="account_name" placeholder="Account Name" name="account_name" value="<?= @$fetched_data[0]['account_name'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="bank_code" class="col-form-label">IFSC Code <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="bank_code" placeholder="Bank Code" name="bank_code" value="<?= @$fetched_data[0]['bank_code'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="bank_name" class="col-form-label">Bank Name <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="bank_name" placeholder="Bank Name" name="bank_name" value="<?= @$fetched_data[0]['bank_name'] ?>" readonly>
                                    </div>
                                </div>
                                </div>
                                </div>
                                
                                <hr>
                                <div class="col-lg-6">
                                <h4>Other Details</h4>
                                <div class="other-details">
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="latitude" class="col-form-label">Latitude <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="latitude" placeholder="Latitude" name="latitude" value="<?= @$fetched_data[0]['latitude'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="longitude" class="col-form-label">Longitude <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="longitude" placeholder="Longitude" name="longitude" value="<?= @$fetched_data[0]['longitude'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row d-none">
                                    <div class="col-sm-12">
                                        <label for="tax_name" class="col-form-label">Tax Name <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="tax_name" placeholder="Tax Name" name="tax_name" value="<?= @$fetched_data[0]['tax_name'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="tax_number" class="col-form-label">GST Number <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="tax_number" placeholder="Tax Number" name="tax_number" value="<?= @$fetched_data[0]['tax_number'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label for="pan_number" class="col-form-label">Pan Number <span class='text-danger text-sm'></span></label>
                                        <input type="text" class="form-control" id="pan_number" placeholder="Pan Number" name="pan_number" value="<?= @$fetched_data[0]['pan_number'] ?>" readonly>
                                    </div>
                                </div>
                                </div>
                                </div>
                                <div class="form-group row d-none">
                                    <label class="col-sm-2 col-form-label">Status <span class='text-danger text-sm'>*</span></label>
                                    <div id="status" class="btn-group col-sm-4">
                                        <label class="btn btn-default" data-toggle-class="btn-default" data-toggle-passive-class="btn-default">
                                            <input type="radio" name="status" value="0" <?= (isset($fetched_data[0]['status']) && $fetched_data[0]['status'] == '0') ? 'Checked' : '' ?>> Deactive
                                        </label>
                                        <label class="btn btn-primary" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                            <input type="radio" name="status" value="1" <?= (isset($fetched_data[0]['status']) && $fetched_data[0]['status'] == '1') ? 'Checked' : '' ?>> Active
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group row d-none">
                                    <label for="national_identity_card" class="col-sm-2 col-form-label">National Identity Card <span class='text-danger text-sm'>*</span></label>
                                    <div class="col-sm-10">
                                        <?php if (isset($fetched_data[0]['national_identity_card']) && !empty($fetched_data[0]['national_identity_card'])) { ?>
                                            <span class="text-danger">*Leave blank if there is no change</span>
                                        <?php } ?>
                                        <input type="file" class="form-control" name="national_identity_card" id="national_identity_card" accept="image/*" />
                                    </div>
                                </div>
                                <?php if (isset($fetched_data[0]['national_identity_card']) && !empty($fetched_data[0]['national_identity_card'])) { ?>
                                    <div class="form-group row">
                                        <div class="mx-auto product-image"><a href="<?= base_url($fetched_data[0]['national_identity_card']); ?>" data-toggle="lightbox" data-gallery="gallery_seller"><img src="<?= base_url($fetched_data[0]['national_identity_card']); ?>" class="img-fluid rounded"></a></div>
                                    </div>
                                <?php } ?>


                                <div class="form-group">
                                    <button type="reset" class="btn btn-warning d-none">Reset</button>
                                    <button type="submit" class="btn btn-success d-none" id="submit_btn">Update Profile</button>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <div class="form-group" id="error_box">
                                    <div class="card text-white d-none mb-3">
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-footer -->
                        </form>


                    </div>
                    <!--/.card-->
                </div>
                <!--/.col-md-12-->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>