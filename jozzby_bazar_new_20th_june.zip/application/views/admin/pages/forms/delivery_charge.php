
<p>hello</p>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h4>Delivery Charge</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('admin/home') ?>">Home</a></li>
                        <li class="breadcrumb-item active">Delivery</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-info">
                        <form class="form-horizontal form-submit-event" action="<?= base_url('admin/offer/add_charge'); ?>" method="POST" id="payment_setting_form" enctype="multipart/form-data">
                            <div class="card-body">
                                <div class="form-group">
                                    <?php if (isset($fetched_data[0]['id'])) {
                                    ?>
                                        <input type="hidden" name="edit_delivery_charge" value="<?= $fetched_data[0]['id'] ?>">
                                    <?php } ?>
                                    <label for="offer_type">Minimum Charge<span class='text-danger text-sm'>*</span> </label>
                                    <input type="text" name = "minimum" placeholder = "Minimum Charge" class = "form-control" value="<?= isset($fetched_data[0]['mimimum'])?output_escaping($fetched_data[0]['minimum']):"" ?>">
                                </div>

                                <div class="form-group">
                                    <label for="offer_type">Maximum Charge<span class='text-danger text-sm'>*</span> </label>
                                    <input type="text" name = "maximum" placeholder = "Maximum Charge" class = "form-control" value="<?= isset($fetched_data[0]['maximum'])?output_escaping($fetched_data[0]['maximum']):"" ?>">
                                </div>
                                <div class="form-group">
                                    <label for="offer_type">Delivery Charge<span class='text-danger text-sm'>*</span> </label>
                                    <input type="text" name = "delivery_charge" placeholder = "Delivery Charge" class = "form-control" value="<?= isset($fetched_data[0]['delivery_charge'])?output_escaping($fetched_data[0]['delivery_charge']):"" ?>">
                                </div>

                                <div class="form-group">
                                    <button type="reset" class="btn btn-warning">Reset</button>
                                    <button type="submit" class="btn btn-success" id="submit_btn"><?= (isset($fetched_data[0]['id'])) ? 'Update Delivery Charge' : 'Add Delivery Charge' ?></button>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <div class="form-group" id="error_box">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!--/.card-->
                </div>
                <!--/.col-md-12-->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>