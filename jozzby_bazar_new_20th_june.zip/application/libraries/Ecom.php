<?php

/**
 *
 * PHP version 5
 *
 * @category Ecom Gateway
 * @package  Ecom Gateway
 */
class Ecom
{
    /**
     * When checking nbf, iat or expiration times,
     * we want to provide some extra leeway time to
     * account for clock skew.
     */

     private $email = "";

     private $password = "";
 
     private $url = "";
 
 
 
     function __construct()
 
     {
 
         $settings = get_settings('shipping_method', true);
 
 
 
         $this->url = "https://apiv2.shiprocket.in/v1/external/";
 
         $this->email = (isset($settings['email'])) ? $settings['email'] : "";
 
         $this->password = (isset($settings['password'])) ? $settings['password'] : "";
 
     }
 
     public function check_serviceability($delivery_pincode)

     {
 
   

 
         $qry_str = http_build_query($query);

   

         $data = array(
 

            "username"=>$this->email,
            "password"=>$this->password,
            "delivery_pincode"=>$delivery_pincode

        );
         $url = 'https://api.ecomexpress.in/apiv3/pincode/';

         $result = $this->curl($url,'POST',$data);
     
 
         return $result;
 
     }
 
 
 

     
    public function curl($url, $method = 'GET', $data = [])

    {
        
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('username' => $data['username'],'password' => $data['password'],'pincode' => $data['delivery_pincode']),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        return $response;
        

    }
    
}

?>