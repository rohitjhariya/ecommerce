<?php
defined('BASEPATH') or exit('No direct script access allowed');
// Separate File For Custom Constant Variables

define('FORMS', 'forms/');
define('TABLES', 'tables/');
