importScripts("https://www.gstatic.com/firebasejs/3.9.0/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/3.9.0/firebase-messaging.js");

var config = {
	apiKey: "AIzaSyCAxOWBbXYuMNKAHoYtqWmwhbf7-NeQmT0",
	authDomain: "eshop-2210d.firebaseapp.com",
	databaseURL: "https://eshop-2210d.firebaseio.com",
	projectId: "eshop-2210d",
	storageBucket: "eshop-2210d.appspot.com",
	messagingSenderId: "365058967814",
    appId: "1:365058967814:web:e205a52dc3abd1719a7687",
    measurementId: "G-1JN518T7J6",
};

firebase.initializeApp(config);